package frame;

import frame.GMainFrame;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class GMain {

    public GMain(){

    }
    public static void main(String[] args) {
        GMainFrame mainFrame = new GMainFrame();
        mainFrame.setVisible(true);

    }
}