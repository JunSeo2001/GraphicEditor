package menus;

import javax.swing.*;

public class GFileMenu extends JMenu {
    private static final long serialVersionUID = 2088557786928073954L;

    public GFileMenu(String s){
        super(s);
    }


}
